<?php
abstract class Piwik_Controller
{
	function getDefaultAction()
	{
		return 'index';
	}
}
?>
