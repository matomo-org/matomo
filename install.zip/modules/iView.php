<?php
interface iView
{
	function render();
}
?>
