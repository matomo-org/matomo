<?php

class Piwik_ExamplePlugin_Controller extends Piwik_Controller
{
	function getDefaultAction()
	{
		return 'homepage';
	}
	
	function homepage()
	{
		// invoke view
		// render view
		// do stuff...
	}
}
