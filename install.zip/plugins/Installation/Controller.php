<?php
require_once "View.php";
require_once "Installation/View.php";
class Piwik_Installation_Controller extends Piwik_Controller
{
	protected $steps = array(
			'welcome',
			'systemCheck',
			'databaseSetup',
			'tablesCreation',
			'generalSetup',
			'firstWebsiteSetup',
			'displayJavascriptCode',
			'finished'
		);
		
	protected $pathView = 'Installation/templates/';
	
	public function __construct()
	{
		session_start();
	}
	public function getInstallationSteps()
	{
		return $this->steps;
	}
	
	function getDefaultAction()
	{
		return $this->steps[0];
	}
	
	function welcome()
	{
		$view = new Piwik_Install_View(
						$this->pathView . 'welcome.tpl', 
						$this->getInstallationSteps(),
						__FUNCTION__
					);
		$view->showNextStep = true;
		echo $view->render();
	}
	
	function systemCheck()
	{
		$view = new Piwik_Install_View(
						$this->pathView . 'systemCheck.tpl', 
						$this->getInstallationSteps(),
						__FUNCTION__
					);
		
		$view->infos = $this->getSystemInformation();
//		var_dump($view->infos);
		$view->showNextStep = true;
		echo $view->render();
	}
	
	function databaseSetup()
	{
		$view = new Piwik_Install_View(
						$this->pathView . 'databaseSetup.tpl', 
						$this->getInstallationSteps(),
						__FUNCTION__
					);
					
		$view->showNextStep = false;
		require_once "FormDatabaseSetup.php";
		$form = new Piwik_Installation_FormDatabaseSetup;
		
		if($form->validate())
		{
//			var_dump(Zend_Registry::get('config')->database);
			$dbInfos = array(
				'host' 			=> $form->getSubmitValue('host'),
				'username' 		=> $form->getSubmitValue('username'),
				'password' 		=> $form->getSubmitValue('password'),
				'dbname' 		=> $form->getSubmitValue('dbname'),
				'tables_prefix' => $form->getSubmitValue('tables_prefix'),
				'adapter' 		=> Zend_Registry::get('config')->database->adapter,
			);
			
			// we test the DB connection with these settings
			try{ 
				Piwik::createDatabaseObject($dbInfos);
				$_SESSION['db_infos'] = $dbInfos;
			
				$this->redirectToNextStep( __FUNCTION__ );
			} catch(Exception $e) {
				$view->errorMessage = $e->getMessage();
			}
		}
		$view->addForm($form);
		
		$view->infos = $this->getSystemInformation();
		echo $view->render();
	}
	
	protected function redirectToNextStep($currentStep)
	{
		$nextStep = $this->steps[1 + array_search($currentStep, $this->steps)];
		Piwik::redirectToModule('Installation' , $nextStep);
	}
	function tablesCreation()
	{
		
		$view = new Piwik_Install_View(
						$this->pathView . 'tablesCreation.tpl', 
						$this->getInstallationSteps(),
						__FUNCTION__
					);
		$dbInfos = $_SESSION['db_infos'];
		
		Zend_Registry::get('config')->database = $dbInfos;
		
		Piwik::createDatabaseObject($dbInfos);
		
		$tablesInstalled = Piwik::getTablesInstalled();
		$tablesToInstall = Piwik::getTablesNames();
		
		if(count($tablesInstalled) > 0)
		{
			$view->someTablesInstalled = true;
		}
		else
		{
			Piwik::createTables();
			
			$view->tablesCreated = true;
		$view->showNextStep = true;
		}
		echo $view->render();
	}
	
	
	public function finished()
	{
		session_destroy();
	}
	
	
	protected function checkDirectoriesWritable()
	{
		$directoriesToCheck = array(
			'/config',
			'/tmp',
			'/tmp/templates_c',
			'/tmp/configs',
			'/tmp/cache',
		); 
		
		$resultCheck = array();
		
		foreach($directoriesToCheck as $name)
		{
			$directoryToCheck = PIWIK_INCLUDE_PATH . $name;
			
			$resultCheck[$name] = false;
			
			if(!is_writable($directoryToCheck))
			{			
				Piwik::mkdir($directoryToCheck);
			}
			
			if(is_writable($directoryToCheck))
			{
				$resultCheck[$name] = true;
			}
		}
		
		return $resultCheck;
	}
	
	protected function getSystemInformation()
	{
		$minimumPhpVersion = Zend_Registry::get('config')->General->minimumPhpVersion;
		$minimumMemoryLimit = Zend_Registry::get('config')->General->minimumMemoryLimit;
		
		$infos = array();
	
		// directory to write
		$infos['directories'] = $this->checkDirectoriesWritable();
		
		// php version
		$infos['phpVersion_minimum'] = $minimumPhpVersion;
		$infos['phpVersion'] = phpversion();
		$infos['phpVersion_ok'] = version_compare( $minimumPhpVersion, $infos['phpVersion']) === -1;
		
		$extensions = @get_loaded_extensions();
		
		// Mysql + version
		if (in_array('pdo_mysql', $extensions))  
		{
		    $infos['pdo_mysql_ok'] = true;
		    //TODO add the mysql version report and check mini 4.1
//			$infos['pdo_mysql_version'] = getMysqlVersion();
		}
		
		// server version
		$infos['serverVersion'] = addslashes($_SERVER['SERVER_SOFTWARE']);
	
		// server os (linux)
		$infos['serverOs'] = @php_uname();
		
		// server time
		$infos['serverTime'] = date('H:i:s');
				
		if(function_exists( 'set_time_limit'))
		{
			$infos['setTimeLimit_ok'] = true;
		}
	
		if(function_exists( 'utf8_encode') 
			&& function_exists( 'utf8_decode'))
		{
			$infos['phpXml_ok'] = true;
		}
		
		if(function_exists('mail'))
		{
			$infos['mail_ok'] = true;
		}
		
		//Registre global
		$infos['registerGlobals_ok'] = ini_get('register_globals') == 0;
		
		$raised = Piwik::raiseMemoryLimitIfNecessary();
		if(	$memoryValue = Piwik::getMemoryLimitValue() )
		{
			$infos['memoryCurrent'] = $memoryValue."M";
			$infos['memoryMinimum'] = $minimumMemoryLimit;
			$infos['memory_ok'] = $memoryValue >= $minimumMemoryLimit;
		}
				/*
		// server uptime from mysql uptime
		$res = query('SHOW STATUS');
		if($res)
		{
			while ($row = mysql_fetch_array($res)) 
			{
			   $serverStatus[$row[0]] = $row[1];
			}
	
			$infos['server_uptime'] = date("r",time() - $serverStatus['Uptime']); 		
		}*/
		
		return $infos;
	}
}
?>
