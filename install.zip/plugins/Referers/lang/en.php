<?php
$translations = array(
	'Referers_DirectEntry' => 'Direct Entry',
	'Referers_SearchEngines' => 'Search Engines',
	'Referers_Websites' => 'Websites',
	'Referers_Partners' => 'Partners',
	'Referers_Newsletters' => 'Newsletters',
	'Referers_Campaigns' => 'Campaigns',
);
 
