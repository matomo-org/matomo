<?php
//TODO should contain the code from the viewDataTable 
