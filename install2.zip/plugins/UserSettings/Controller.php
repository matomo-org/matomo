<?php

class Piwik_UserSettings_Controller extends Piwik_Controller
{	
}