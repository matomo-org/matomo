<?php

/**
 * Matomo - free/libre analytics platform
 *
 * @link    https://matomo.org
 * @license https://www.gnu.org/licenses/gpl-3.0.html GPL v3 or later
 */

namespace Piwik\Plugins\TestPluginUpdate;

class TestPluginUpdate extends \Piwik\Plugin
{
    public function registerEvents()
    {
        return ['Template.jsGlobalVariables' => 'addJsGlobalVariables'];
    }

    public function addJsGlobalVariables(&$out)
    {
        $out .= JsGlobalVariables::get();
    }
}
