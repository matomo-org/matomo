## Changelog

# 5.0.10 - 2026-09-07
- Keep the link icon off treemap rows that have no URL

# 5.0.9 - 2026-09-02
- Improvements in treemap node URL handling

# 5.0.8 - 2026-08-31
- Fixed typo in README.md - (Thanks [@Sumit-Sabhaya](https://github.com/Sumit-Sabhaya/)!)

# 5.0.7 - 2026-04-27
- Updated API documentation

# 5.0.6 - 2026-03-02
- Updated API documentation

# 5.0.5 - 2026-02-16
- Added validation rules for ApiAction

# 5.0.4 - 2025-07-07
- Textual changes

# 5.0.3 - 2025-01-20
- Added code to allow calling Treemap API only directly

# 5.0.2 - 2025-01-10
- Avoids recursion in API calls

# 5.0.1
- Added plugin category for Marketplace

# 5.0.0
- Compatibility with Matomo 5

# 4.0.2
- Translation changes and made plugin translatable
